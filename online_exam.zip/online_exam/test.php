<?php include 'inc/header.php'; ?>

<?php
Session::checkSession();

if(isset($_GET['q'])){
  $number1 = (int)$_GET['q'];   /*here now $number = quesNo*/
}else{
    header("Location:exam.php");
}
$total1    = $exm->getTotalRows1();
$question1 = $exm->getQuesByNumber1($number1);
?>

<?php
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $process = $pro->processData1($_POST);
}
?>

<div class="main">
<h1>Question <?php echo $question1['quesNo']; ?> of <?php echo $total1;?> </h1>
	<div class="test">
		<form method="post" action="">
		<table> 
			<tr>
				<td colspan="2">
				 <h3 style="font-size: 18px">Ques <?php echo $question1['quesNo']; ?>: <?php echo $question1['ques'];?> </h3>
				</td>
			</tr>

            <?php
                $answer1 = $exm->getAnswer1($number1);
            if($answer1){
                while($result1 = $answer1->fetch_assoc()){
            ?>

			<tr>
				<td>
				 <input type="radio" name="ans" value="<?php echo $result1['id']; ?>"/>
                    <?php echo $result1['ans']; ?>
				</td>
			</tr>
			<?php } } ?>

			<tr style="padding-left: 12px;" class="button_next">
			  <td >
				<input type="submit" name="submit" value="Next Question>"/>
				<input type="hidden" name="number" value="<?php echo $number1; ?>"/>
			</td>
			</tr>
			
		</table>
     </form>

</div>
 </div>

<?php include 'inc/footer.php'; ?>