
<?php include 'inc/header.php'; ?>

<?php
Session::checkSession();
$question1 = $exm->getQuestion1();
$total1    = $exm->getTotalRows1();
?>



    <div class="main">
        <h1>Welcome to Online Exam</h1>
        <div style="text-align: center" class="starttest">
            <h2>You are about to begin</h2>
            <p>This quiz is to test your knowledge.</p>
            <ul>
                <li><strong>Number of Questions: </strong> <?php echo $total1; ?> </li>
                <li>Allocated Time: <a style="color: maroon;"> 5</a> minutes </li>
                <li>Timer shall begin! </li>
                
            </ul>
            <br/>
            <br/>

            <a style="color: green; border-color: green; border-radius: 13px" href="test.php?q=<?php echo $question1['quesNo']; ?>">MCQ</a>
        <a style="color: green; border-color: green; border-radius: 13px" href="test2.php?q=<?php echo $question1['quesNo']; ?>">T/F</a>
          <a style="color: green; border-color: green; border-radius: 13px" href="test3.php?q=<?php echo $question1['quesNo']; ?>">Single Choice</a>
        </div>
    </div>
<?php include 'inc/footer.php'; ?>