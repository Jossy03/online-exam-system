 </section>
<section class="footeroption">
		<h3><?php echo "©  周希 Simple Online Exam System"; ?></h3>
	</section>
</div>
</body>
</html>