<?php
$filepath = realpath(dirname(__FILE__));
include_once ($filepath.'/inc/header.php');
include_once ($filepath.'/../classes/Exam.php');

$exm3 = new Exam3();

?>

  <style>
      .adminpanel{
          border: 1px solid #dddddd;
          border-radius: 12px;
          color: #999999;
          margin: 18px auto 0;
          padding: 15px;
          width: 650px;
      }
  </style>

    <?php
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        $addQues = $exm3->addQuestions($_POST);
    }
     /*get total*/
     $total = $exm3->getTotalRows();
     $next = $total + 1;
    ?>

  

  
  
  
    <div class="main">
        <br><br><br>
        
        <h1 style="text-align: center; color:#483D8B; font-size: 24px">Add Question SC</h1>

        <?php
           if(isset($addQues)){
               echo $addQues;
           }
        ?>

        <div class="adminpanel">
             <form action="" method="post">
                <table>
                    <tr>  <tr> </tr>
                        <td>Question No</td>
                        <td>:</td>
                        <td>  
                            <input type="number" value="<?php
                               if(isset($next)){
                                   echo $next;
                               }
                            ?>" name="quesNo"/></td>
                    </tr>
                    <tr>
                        <td>Question</td>
                        <td>:</td>
                        <td><input type="text" name="ques" placeholder="Enter a Question" required=""/></td>
                    </tr>
                    <tr>
                        <td>Choice One</td>
                        <td>:</td>
                        <td><input type="text" name="ans1" placeholder="Enter Choice One..." required=""/></td>
                    </tr>
                   
                    <tr>
                        <td>Correct No</td>
                        <td>:</td>
                        <td><input type="number" name="rightAns" required=""/></td>
                    </tr>
                    <tr>
                        <td class="button_class" colspan="3" align="center">
                            <input style="color: green;" type="submit" value="Add a Question" required=""/>
                        </td>
                      </tr>

     
                 
                   
                   
                   
                   
                      
                   
                </table>
            </form>
            
            <table>
                
                <tr>  <br><br><br>
                    
                    <td  colspan="3" align="right"  > 
                        <a    href="quesAdd.php" >
    <button style="color: maroon;"     >Multiple Choice</button>
                        </a></td>  <td><a>&nbsp;</a></td>
                        <td  colspan="3" align="right"  > 
                        <a    href="quesAdd2.php" >
    <button style="color: maroon;"     >True or False</button>
                        </a></td>
                    </tr>
                 
                
                
            </table>
            
            
        </div>


    </div>
  
  
  





  
  
  
<?php include 'inc/footer.php'; ?>