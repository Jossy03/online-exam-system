<?php


$serverName = "localhost";
$username = "root";
$password = "";
$dbName = "db_exam";


$con = mysqli_connect($serverName,$username,$password,$dbname);


if(mysqli_connect_errno()){
    echo "failed to connect";
    exit();
}
echo "connection success"

?>




