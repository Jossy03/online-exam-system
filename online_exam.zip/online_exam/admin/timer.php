
<html>

<head>
    <title></title>
     
    
</head>
<body>
    
    <?php
    $sql = "SELECT * FROM timer;";
    $result = mysqli_query ($conn, $sql);
    $resultcheck = mysqli_num_rows (result);
    
    if ($resultcheck > 0) {
        while ($row = mysqli_fetch_assoc($result)){
            echo $row['time'];
        }
    }
    ?>
    
</body>
</html>