<?php
$filepath = realpath(dirname(__FILE__));
include_once ($filepath.'/../lib/Session.php');
include_once ($filepath.'/../lib/Database.php');
include_once ($filepath.'/../helpers/Format.php');

class Process{
    private $db;
    private $fm;
    public function __construct(){
        $this->db = new Database();
        $this->fm = new Format();
    }

    public function processData1($data){
        $selectedAns1 = $this->fm->validation($data['ans']);
        $number1      = $this->fm->validation($data['number']);
        $selectedAns1 = mysqli_real_escape_string($this->db->link, $selectedAns1);
        $number1      = mysqli_real_escape_string($this->db->link, $number1);
        $next1 = $number1 + 1;

        if(!isset($_SESSION['score'])) {
            $_SESSION['score'] = '0';
        }

        $total1 = $this->getTotal();
        $right1 = $this->rightAns1($number1);
        if($right1 == $selectedAns1){
            $_SESSION['score']++;
        }

        if($number1 == $total1){
            if($_SESSION['score'] == $total1){
                header("Location:viva.php");
                exit();
            }else{
                header("Location:final.php");
                exit();
            }
        }else{
            header("Location:test.php?q=".$next1);
        }
    }

    
    
    private function getTotal1(){
        $query1     = "SELECT * FROM tbl_ques";
        $getResult1 = $this->db->select($query1);
        $total1     = $getResult1->num_rows;
        return $total1;
    }

    private function rightAns1($number1){
        $query1    = "SELECT * FROM tbl_ans WHERE quesNo='$number1' AND rightAns='1'";
        $get_data1 = $this->db->select($query1)->fetch_assoc();
        $result1   = $get_data1['id'];
        return $result1;
    }
    
}



class Process2{
    private $db;
    private $fm;
    public function __construct(){
        $this->db = new Database();
        $this->fm = new Format();
    }

    
    public function processData2($data){
        $selectedAns = $this->fm->validation($data['ans']);
        $number      = $this->fm->validation($data['number']);
        $selectedAns = mysqli_real_escape_string($this->db->link, $selectedAns);
        $number      = mysqli_real_escape_string($this->db->link, $number);
        $next = $number + 1;

        if(!isset($_SESSION['score'])) {
            $_SESSION['score'] = '0';
        }

        $total = $this->getTotal();
        $right = $this->rightAns($number);
        if($right == $selectedAns){
            $_SESSION['score']++;
        }

        if($number == $total){
            if($_SESSION['score'] == $total){
                header("Location:viva.php");
                exit();
            }else{
                header("Location:final.php");
                exit();
            }
        }else{
            header("Location:test2.php?q=".$next);
        }
    }
    
    
    
    private function getTotal2(){
        $query     = "SELECT * FROM tbl_ques2";
        $getResult = $this->db->select($query);
        $total     = $getResult->num_rows;
        return $total;
    }

    private function rightAns2($number){
        $query    = "SELECT * FROM tbl_ans2 WHERE quesNo='$number' AND rightAns='1'";
        $get_data = $this->db->select($query)->fetch_assoc();
        $result   = $get_data['id'];
        return $result;
    }
    
}







?>