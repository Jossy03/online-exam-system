<?php
$filepath = realpath(dirname(__FILE__));
include_once ($filepath.'/../lib/Database.php');
include_once ($filepath.'/../helpers/Format.php');

class Exam{
    private $db;
    private $fm;
    public function __construct(){
        $this->db = new Database();
        $this->fm = new Format();
    }

    public function addQuestions1($data){
        $quesNo1 = mysqli_real_escape_string($this->db->link, $data['quesNo']);
        $ques1   = mysqli_real_escape_string($this->db->link, $data['ques']);

        $ans       = array();
        $ans[1]   = $data['ans1'];
        $ans[2]   = $data['ans2'];
        $ans[3]   = $data['ans3'];
        $ans[4]   = $data['ans4'];
        $rightAns = $data['rightAns'];

        $query1 = "INSERT INTO tbl_ques(quesNo, ques) VALUES('$quesNo1', '$ques1')";
        $insert_row1 = $this->db->insert1($query1);

        if($insert_row1){
            foreach($ans as $key => $ansName1){
                if($ansName1 != ''){
                    if($rightAns1 == $key){
                        $r_query1 = "INSERT INTO tbl_ans(quesNo, rightAns, ans) VALUES('$quesNo1', '1', '$ansName1')";
                    }else{
                        $r_query1 = "INSERT INTO tbl_ans(quesNo, rightAns, ans) VALUES('$quesNo1', '0', '$ansName1')";
                    }
                    $insertTheRow1 = $this->db->insert1($r_query1);
                    if($insertTheRow1){
                        continue;
                    }else{
                        die('Error..');
                    }
                }
            }
            $msg = "<span style='font-size: 17px' class='success'>Question Added Successfully!</span>";
            return $msg;
        }
    }

    public function getQuesByOrder1(){
        $query1  = "SELECT * FROM tbl_ques ORDER BY quesNo ASC";
        $result1 = $this->db->select1($query1);
        return $result1;
    }

    /*join tbl_ques and tbl_ans*/
    public function delQuestion1($quesNo1){
        $tables1 = array("tbl_ques","tbl_ans");
        foreach ($tables1 as $table1) {
            $delQuery1 = "DELETE FROM $table1 WHERE QuesNo = '$quesNo1'";
            $delData1  = $this->db->delete1($delQuery1);
        }
        if($delData1){
            $msg = "<span style='font-size: 17px' class='success'>Question Deleted Successfully!</span>";
            return $msg;
        }else{
            $msg = "<span style='font-size: 17px' class='success'>Question Not Deleted!</span>";
            return $msg;
        }
    }

    public function getTotalRows1(){
        $query1     = "SELECT * FROM tbl_ques";
        $getResult1 = $this->db->select1($query1);
        $total1     = $getResult1->num_rows;
        return $total1;
    }

    public function getQuestion1(){
        $query1     = "SELECT * FROM tbl_ques";
        $getData1   = $this->db->select1($query1);
        $result1    = $getData1->fetch_assoc();
        return $result1;
    }

    public function getQuesByNumber1($number1){
        $query1     = "SELECT * FROM tbl_ques WHERE quesNo = '$number1'";
        $getDataRow1   = $this->db->select1($query1);
        $result1    = $getDataRow1->fetch_assoc();
        return $result1;
    }

    public function getAnswer1($number1){
        $query1       = "SELECT * FROM tbl_ans WHERE quesNo = '$number1'";
        $getData1 = $this->db->select1($query1);
        return $getData1;
    }



}














class Exam2{
    private $db;
    private $fm;
    public function __construct(){
        $this->db = new Database();
        $this->fm = new Format();
    }

    public function addQuestions($data){
        $quesNo = mysqli_real_escape_string($this->db->link, $data['quesNo']);
        $ques   = mysqli_real_escape_string($this->db->link, $data['ques']);

        $ans       = array();
        $ans[1]   = $data['ans1'];
        $ans[2]   = $data['ans2'];
 
        $rightAns = $data['rightAns'];

        $query = "INSERT INTO tbl_questwo(quesNo, ques) VALUES('$quesNo', '$ques')";
        $insert_row = $this->db->insert($query);

        if($insert_row){
            foreach($ans as $key => $ansName){
                if($ansName != ''){
                    if($rightAns == $key){
                        $r_query = "INSERT INTO tbl_anstwo(quesNo, rightAns, ans) VALUES('$quesNo', '1', '$ansName')";
                    }else{
                        $r_query = "INSERT INTO tbl_anstwo(quesNo, rightAns, ans) VALUES('$quesNo', '0', '$ansName')";
                    }
                    $insertTheRow = $this->db->insert($r_query);
                    if($insertTheRow){
                        continue;
                    }else{
                        die('Error..');
                    }
                }
            }
            $msg = "<span style='font-size: 17px' class='success'>Question Added Successfully!</span>";
            return $msg;
        }
    }

    public function getQuesByOrder(){
        $query  = "SELECT * FROM tbl_questwo ORDER BY quesNo ASC";
        $result2 = $this->db->select($query);
        return $result2;
    }

    /*join tbl_ques and tbl_ans*/
    public function delQuestion($quesNo){
        $tables = array("tbl_questwo","tbl_anstwo");
        foreach ($tables as $table) {
            $delQuery = "DELETE FROM $table WHERE QuesNo = '$quesNo'";
            $delData  = $this->db->delete($delQuery);
        }
        if($delData){
            $msg = "<span style='font-size: 17px' class='success'>Question Deleted Successfully!</span>";
            return $msg;
        }else{
            $msg = "<span style='font-size: 17px' class='success'>Question Not Deleted!</span>";
            return $msg;
        }
    }

    public function getTotalRows(){
        $query     = "SELECT * FROM tbl_questwo";
        $getResult = $this->db->select($query);
        $total     = $getResult->num_rows;
        return $total;
    }

    public function getQuestion(){
        $query     = "SELECT * FROM tbl_questwo";
        $getData   = $this->db->select($query);
        $result    = $getData->fetch_assoc();
        return $result;
    }

    public function getQuesByNumber($number){
        $query     = "SELECT * FROM tbl_questwo WHERE quesNo = '$number'";
        $getDataRow   = $this->db->select($query);
        $result    = $getDataRow->fetch_assoc();
        return $result;
    }

    public function getAnswer($number){
        $query       = "SELECT * FROM tbl_anstwo WHERE quesNo = '$number'";
        $getData = $this->db->select($query);
        return $getData;
    }



}















class Exam3{
    private $db;
    private $fm;
    public function __construct(){
        $this->db = new Database();
        $this->fm = new Format();
    }

    public function addQuestions($data){
        $quesNo = mysqli_real_escape_string($this->db->link, $data['quesNo']);
        $ques   = mysqli_real_escape_string($this->db->link, $data['ques']);

        $ans       = array();
        $ans[1]   = $data['ans1'];
    
 
        $rightAns = $data['rightAns'];

        $query = "INSERT INTO tbl_questhree(quesNo, ques) VALUES('$quesNo', '$ques')";
        $insert_row = $this->db->insert($query);

        if($insert_row){
            foreach($ans as $key => $ansName){
                if($ansName != ''){
                    if($rightAns == $key){
                        $r_query = "INSERT INTO tbl_ansthree(quesNo, rightAns, ans) VALUES('$quesNo', '1', '$ansName')";
                    }else{
                        $r_query = "INSERT INTO tbl_ansthree(quesNo, rightAns, ans) VALUES('$quesNo', '0', '$ansName')";
                    }
                    $insertTheRow = $this->db->insert($r_query);
                    if($insertTheRow){
                        continue;
                    }else{
                        die('Error..');
                    }
                }
            }
            $msg = "<span style='font-size: 17px' class='success'>Question Added Successfully!</span>";
            return $msg;
        }
    }

    public function getQuesByOrder(){
        $query  = "SELECT * FROM tbl_questhree ORDER BY quesNo ASC";
        $result2 = $this->db->select($query);
        return $result2;
    }

    /*join tbl_ques and tbl_ans*/
    public function delQuestion($quesNo){
        $tables = array("tbl_questhree","tbl_ansthree");
        foreach ($tables as $table) {
            $delQuery = "DELETE FROM $table WHERE QuesNo = '$quesNo'";
            $delData  = $this->db->delete($delQuery);
        }
        if($delData){
            $msg = "<span style='font-size: 17px' class='success'>Question Deleted Successfully!</span>";
            return $msg;
        }else{
            $msg = "<span style='font-size: 17px' class='success'>Question Not Deleted!</span>";
            return $msg;
        }
    }

    public function getTotalRows(){
        $query     = "SELECT * FROM tbl_questhree";
        $getResult = $this->db->select($query);
        $total     = $getResult->num_rows;
        return $total;
    }

    public function getQuestion(){
        $query     = "SELECT * FROM tbl_questhree";
        $getData   = $this->db->select($query);
        $result    = $getData->fetch_assoc();
        return $result;
    }

    public function getQuesByNumber($number){
        $query     = "SELECT * FROM tbl_questhree WHERE quesNo = '$number'";
        $getDataRow   = $this->db->select($query);
        $result    = $getDataRow->fetch_assoc();
        return $result;
    }

    public function getAnswer($number){
        $query       = "SELECT * FROM tbl_ansthree WHERE quesNo = '$number'";
        $getData = $this->db->select($query);
        return $getData;
    }



}







?>